<!-- ....................................................................... -->
<!-- SVG 1.1 Basic Font Module ............................................. -->
<!-- file: svg-basic-font.mod

     This is SVG, a language for describing two-dimensional graphics in XML.
     Copyright 2001, 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
     Revision: $Id: svg-basic-font.mod,v 1.1 2003/07/16 01:23:38 mikeday Exp $

     This DTD module is identified by the PUBLIC and SYSTEM identifiers:

        PUBLIC "-//W3C//ELEMENTS SVG 1.1 Basic Font//EN"
        SYSTEM "http://www.w3.org/Graphics/SVG/1.1/DTD/svg-basic-font.mod"

     ....................................................................... -->

<!-- Basic Font

        font, font-face, glyph, missing-glyph, hkern, font-face-src,
        font-face-name

     This module declares markup to provide support for template.
-->

<!-- Qualified Names (Default) ......................... -->

<!ENTITY % SVG.font.qname "font" >
<!ENTITY % SVG.font-face.qname "font-face" >
<!ENTITY % SVG.glyph.qname "glyph" >
<!ENTITY % SVG.missing-glyph.qname "missing-glyph" >
<!ENTITY % SVG.hkern.qname "hkern" >
<!ENTITY % SVG.font-face-src.qname "font-face-src" >
<!ENTITY % SVG.font-face-name.qname "font-face-name" >

<!-- Attribute Collections (Default) ................... -->

<!ENTITY % SVG.Core.attrib "" >
<!ENTITY % SVG.Container.attrib "" >
<!ENTITY % SVG.Style.attrib "" >
<!ENTITY % SVG.Viewport.attrib "" >
<!ENTITY % SVG.Text.attrib "" >
<!ENTITY % SVG.TextContent.attrib "" >
<!ENTITY % SVG.Font.attrib "" >
<!ENTITY % SVG.Paint.attrib "" >
<!ENTITY % SVG.Color.attrib "" >
<!ENTITY % SVG.Opacity.attrib "" >
<!ENTITY % SVG.Graphics.attrib "" >
<!ENTITY % SVG.Marker.attrib "" >
<!ENTITY % SVG.ColorProfile.attrib "" >
<!ENTITY % SVG.Gradient.attrib "" >
<!ENTITY % SVG.Clip.attrib "" >
<!ENTITY % SVG.Mask.attrib "" >
<!ENTITY % SVG.Filter.attrib "" >
<!ENTITY % SVG.FilterColor.attrib "" >
<!ENTITY % SVG.Cursor.attrib "" >
<!ENTITY % SVG.XLinkRequired.attrib "" >
<!ENTITY % SVG.External.attrib "" >

<!-- SVG.Font.class .................................... -->

<!ENTITY % SVG.Font.extra.class "" >

<!ENTITY % SVG.Font.class
    "| %SVG.font.qname; | %SVG.font-face.qname; %SVG.Font.extra.class;"
>

<!-- font: Font Element ................................ -->

<!ENTITY % SVG.font.extra.content "" >

<!ENTITY % SVG.font.element "INCLUDE" >
<![%SVG.font.element;[
<!ENTITY % SVG.font.content
    "(( %SVG.Description.class; )*, %SVG.font-face.qname;,
        %SVG.missing-glyph.qname;, ( %SVG.glyph.qname; | %SVG.hkern.qname;
        %SVG.font.extra.content; )*)"
>
<!ELEMENT %SVG.font.qname; %SVG.font.content; >
<!-- end of SVG.font.element -->]]>

<!ENTITY % SVG.font.attlist "INCLUDE" >
<![%SVG.font.attlist;[
<!ATTLIST %SVG.font.qname;
    %SVG.Core.attrib;
    %SVG.Style.attrib;
    %SVG.External.attrib;
    horiz-origin-x %Number.datatype; #IMPLIED
    horiz-adv-x %Number.datatype; #REQUIRED
>
<!-- end of SVG.font.attlist -->]]>

<!-- font-face: Font Face Element ...................... -->

<!ENTITY % SVG.font-face.extra.content "" >

<!ENTITY % SVG.font-face.element "INCLUDE" >
<![%SVG.font-face.element;[
<!ENTITY % SVG.font-face.content
    "(( %SVG.Description.class; )*, %SVG.font-face-src.qname;?
        %SVG.font-face.extra.content; )"
>
<!ELEMENT %SVG.font-face.qname; %SVG.font-face.content; >
<!-- end of SVG.font-face.element -->]]>

<!ENTITY % SVG.font-face.attlist "INCLUDE" >
<![%SVG.font-face.attlist;[
<!ATTLIST %SVG.font-face.qname;
    %SVG.Core.attrib;
    font-family CDATA #IMPLIED
    font-style CDATA #IMPLIED
    font-variant CDATA #IMPLIED
    font-weight CDATA #IMPLIED
    font-stretch CDATA #IMPLIED
    font-size CDATA #IMPLIED
    unicode-range CDATA #IMPLIED
    units-per-em %Number.datatype; #IMPLIED
    panose-1 CDATA #IMPLIED
    stemv %Number.datatype; #IMPLIED
    stemh %Number.datatype; #IMPLIED
    slope %Number.datatype; #IMPLIED
    cap-height %Number.datatype; #IMPLIED
    x-height %Number.datatype; #IMPLIED
    accent-height %Number.datatype; #IMPLIED
    ascent %Number.datatype; #IMPLIED
    descent %Number.datatype; #IMPLIED
    widths CDATA #IMPLIED
    bbox CDATA #IMPLIED
    ideographic %Number.datatype; #IMPLIED
    alphabetic %Number.datatype; #IMPLIED
    mathematical %Number.datatype; #IMPLIED
    hanging %Number.datatype; #IMPLIED
    underline-position %Number.datatype; #IMPLIED
    underline-thickness %Number.datatype; #IMPLIED
    strikethrough-position %Number.datatype; #IMPLIED
    strikethrough-thickness %Number.datatype; #IMPLIED
    overline-position %Number.datatype; #IMPLIED
    overline-thickness %Number.datatype; #IMPLIED
>
<!-- end of SVG.font-face.attlist -->]]>

<!-- glyph: Glyph Element .............................. -->

<!ENTITY % SVG.glyph.extra.content "" >

<!ENTITY % SVG.glyph.element "INCLUDE" >
<![%SVG.glyph.element;[
<!ENTITY % SVG.glyph.content
    "( %SVG.Description.class; %SVG.glyph.extra.content; )*"
>
<!ELEMENT %SVG.glyph.qname; %SVG.glyph.content; >
<!-- end of SVG.glyph.element -->]]>

<!ENTITY % SVG.glyph.attlist "INCLUDE" >
<![%SVG.glyph.attlist;[
<!ATTLIST %SVG.glyph.qname;
    %SVG.Core.attrib;
    %SVG.Style.attrib;
    unicode CDATA #IMPLIED
    glyph-name CDATA #IMPLIED
    d %PathData.datatype; #IMPLIED
    arabic-form CDATA #IMPLIED
    lang %LanguageCodes.datatype; #IMPLIED
    horiz-adv-x %Number.datatype; #IMPLIED
>
<!-- end of SVG.glyph.attlist -->]]>

<!-- missing-glyph: Missing Glyph Element .............. -->

<!ENTITY % SVG.missing-glyph.extra.content "" >

<!ENTITY % SVG.missing-glyph.element "INCLUDE" >
<![%SVG.missing-glyph.element;[
<!ENTITY % SVG.missing-glyph.content
    "( %SVG.Description.class; %SVG.missing-glyph.extra.content; )*"
>
<!ELEMENT %SVG.missing-glyph.qname; %SVG.missing-glyph.content; >
<!-- end of SVG.missing-glyph.element -->]]>

<!ENTITY % SVG.missing-glyph.attlist "INCLUDE" >
<![%SVG.missing-glyph.attlist;[
<!ATTLIST %SVG.missing-glyph.qname;
    %SVG.Core.attrib;
    %SVG.Style.attrib;
    d %PathData.datatype; #IMPLIED
    horiz-adv-x %Number.datatype; #IMPLIED
>
<!-- end of SVG.missing-glyph.attlist -->]]>

<!-- hkern: Horizontal Kerning Element ................. -->

<!ENTITY % SVG.hkern.element "INCLUDE" >
<![%SVG.hkern.element;[
<!ENTITY % SVG.hkern.content "EMPTY" >
<!ELEMENT %SVG.hkern.qname; %SVG.hkern.content; >
<!-- end of SVG.hkern.element -->]]>

<!ENTITY % SVG.hkern.attlist "INCLUDE" >
<![%SVG.hkern.attlist;[
<!ATTLIST %SVG.hkern.qname;
    %SVG.Core.attrib;
    u1 CDATA #IMPLIED
    g1 CDATA #IMPLIED
    u2 CDATA #IMPLIED
    g2 CDATA #IMPLIED
    k %Number.datatype; #REQUIRED
>
<!-- end of SVG.hkern.attlist -->]]>

<!-- font-face-src: Font Face Source Element ........... -->

<!ENTITY % SVG.font-face-src.extra.content "" >

<!ENTITY % SVG.font-face-src.element "INCLUDE" >
<![%SVG.font-face-src.element;[
<!ENTITY % SVG.font-face-src.content
    "( %SVG.font-face-name.qname; %SVG.font-face-src.extra.content; )+"
>
<!ELEMENT %SVG.font-face-src.qname; %SVG.font-face-src.content; >
<!-- end of SVG.font-face-src.element -->]]>

<!ENTITY % SVG.font-face-src.attlist "INCLUDE" >
<![%SVG.font-face-src.attlist;[
<!ATTLIST %SVG.font-face-src.qname;
    %SVG.Core.attrib;
>
<!-- end of SVG.font-face-src.attlist -->]]>

<!-- font-face-name: Font Face Name Element ............ -->

<!ENTITY % SVG.font-face-name.element "INCLUDE" >
<![%SVG.font-face-name.element;[
<!ENTITY % SVG.font-face-name.content "EMPTY" >
<!ELEMENT %SVG.font-face-name.qname; %SVG.font-face-name.content; >
<!-- end of SVG.font-face-name.element -->]]>

<!ENTITY % SVG.font-face-name.attlist "INCLUDE" >
<![%SVG.font-face-name.attlist;[
<!ATTLIST %SVG.font-face-name.qname;
    %SVG.Core.attrib;
    name CDATA #IMPLIED
>
<!-- end of SVG.font-face-name.attlist -->]]>

<!-- end of svg-basic-font.mod -->
